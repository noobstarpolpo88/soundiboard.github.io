using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

public class Sondiboard : Form {
    private dynamic player = Activator.CreateInstance(Type.GetTypeFromProgID("WMPlayer.OCX.7"));
    private Label lblFileType;
    private PictureBox picPreview;
    private TrackBar volSlider;

    public Sondiboard() {
        this.Text = "Alex's Sondiboard";
        this.Size = new Size(600, 550);
        this.BackColor = Color.Silver;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.StartPosition = FormStartPosition.CenterScreen;

        // SIDEBAR
        Label lblSideTitle = new Label { Text = "FILE PREVIEW:", Location = new Point(380, 20), Font = new Font("Arial", 10, FontStyle.Bold), AutoSize = true };
        this.Controls.Add(lblSideTitle);

        picPreview = new PictureBox {
            Location = new Point(380, 50),
            Size = new Size(180, 150),
            BorderStyle = BorderStyle.Fixed3D,
            SizeMode = PictureBoxSizeMode.StretchImage,
            BackColor = Color.Black
        };
        this.Controls.Add(picPreview);

        lblFileType = new Label { 
            Text = "Select a sound...", 
            Location = new Point(380, 210), 
            Size = new Size(180, 80),
            Font = new Font("Courier New", 9, FontStyle.Bold)
        };
        this.Controls.Add(lblFileType);

        // VOLUME
        volSlider = new TrackBar { Location = new Point(20, 320), Width = 320, Minimum = 0, Maximum = 100, Value = 100 };
        volSlider.Scroll += (s, e) => { player.settings.volume = volSlider.Value; };
        this.Controls.Add(volSlider);

        // BUTTONS
        AddBtn("STARTUP", 20, 20, "START.WAV");
        AddBtn("MICROSOFT", 20, 80, "The Microsoft Sound.wav");
        AddBtn("TADA", 20, 140, "TADA.WAV");
        AddBtn("LOGOFF", 20, 200, "LOGOFF.WAV");
        AddBtn("DING", 180, 20, "DING.WAV");
        AddBtn("CHORD", 180, 80, "CHORD.WAV");
        AddBtn("RECYCLE", 180, 140, "RECYCLE.WAV");
        AddBtn("NOTIFY", 180, 200, "NOTIFY.WAV");
    }

    void AddBtn(string txt, int x, int y, string file) {
        Button b = new Button { Text = txt, Location = new Point(x, y), Size = new Size(150, 50), FlatStyle = FlatStyle.Standard };
        b.Click += (s, e) => {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string soundPath = Path.Combine(baseDir, "sounds", file);
            if (File.Exists(soundPath)) {
                player.URL = soundPath;
                player.controls.play();
                lblFileType.Text = "FILE: " + file.ToUpper() + "\nTYPE: " + Path.GetExtension(soundPath).ToUpper();

                string specImg = Path.Combine(baseDir, "sounds", Path.GetFileNameWithoutExtension(file) + ".jpg");
                string placeholderImg = Path.Combine(baseDir, "sounds", "placeholder.jpg");

                if (picPreview.Image != null) picPreview.Image.Dispose();
                
                if (File.Exists(specImg)) picPreview.Image = Image.FromFile(specImg);
                else if (File.Exists(placeholderImg)) picPreview.Image = Image.FromFile(placeholderImg);
                picPreview.Refresh();
            }
        };
        this.Controls.Add(b);
    }

    [STAThread] static void Main() { Application.Run(new Sondiboard()); }
}